@echo off
start chrome --app=http://localhost:3000/Dashboard || start msedge --app=http://localhost:3000/Dashboard || start http://localhost:3000/Dashboard
