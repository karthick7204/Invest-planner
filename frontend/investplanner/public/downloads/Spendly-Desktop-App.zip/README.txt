Spendly Application (v2.4 - Salt & Pepper Engine)
=================================================
macOS:
- Drag Spendly.app to your Applications folder or Dock.
- Double-click to launch in dedicated standalone window mode.

Windows:
- Double-click Spendly-Windows-Launcher.bat to open as a dedicated application.
